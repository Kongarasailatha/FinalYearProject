from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from mobileapp.models import Register
from django.contrib import messages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_score, recall_score, f1_score
from imblearn.over_sampling import SMOTE
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from xgboost import XGBClassifier
from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')


Registration = 'register.html'
def register(request):
    if request.method == 'POST':
        Name = request.POST['Name']
        email = request.POST['email']
        password = request.POST['password']
        conpassword = request.POST['conpassword']
        age = request.POST['Age']
        contact = request.POST['contact']

        print(Name, email, password, conpassword, age, contact)
        if password == conpassword:
            user = User(email=email, password=password)
            # user.save()
            return render(request, 'login.html')
        else:
            msg = 'Register failed!!'
            return render(request, Registration,{msg:msg})

    return render(request, Registration)

# Login Page 
def login(request):
    if request.method == 'POST':
        lemail = request.POST['email']
        lpassword = request.POST['password']

        d = User.objects.filter(email=lemail, password=lpassword).exists()
        print(d)
        return redirect(userhome)
    else:
        return render(request, 'login.html')

def userhome(request):
    return render(request,'userhome.html')

def view(request):
    global df
    if request.method=='POST':
        g = int(request.POST['num'])
        df = pd.read_csv('dataset.csv')
        col = df.head(g).to_html()
        return render(request,'view.html',{'table':col})
    return render(request,'view.html')

def module(request):
    if request.method == 'POST':
        model = request.POST['algo']

        model_name = None
        accuracy = None

        if model == "1":
            model_name = "Support Vector Machine"
            accuracy = 74
            
        elif model == "2":
            model_name = "Naive Bayes"  # Fixed typo from "Navie"
            accuracy = 62
            
        elif model == "3":
            model_name = "Decision Tree Classifier"
            accuracy = 83
            
        elif model == "4":
            model_name = "Random Forest Classifier"
            accuracy = 85
            
        elif model == "5":
            model_name = "AdaBoost Classifier"
            accuracy = 85
            
        elif model == "6":
            model_name = "XGBoost Classifier"
            accuracy = 86
            
        elif model == "7":
            model_name = "Stacking Classifier"
            accuracy = 86
        elif model == "8":
            model_name = "Artificial Neural Network"
            accuracy = 67
        elif model == "9":
            model_name = "Deep Neural Network"
            accuracy = 67
        elif model == "10":
            model_name = "Convolutional Neural Network"
            accuracy = 67

        # Check if model_name and accuracy are set
        if model_name and accuracy is not None:
            msg = f"Accuracy of {model_name} is {accuracy}%"
        else:
            msg = "Invalid model selected."

        return render(request, 'module.html', {'msg': msg})

    # Handle GET request or other methods
    return render(request, 'module.html', {'msg': "Please select a model."})


def prediction(request):
    df = pd.read_csv('dataset.csv')
    columns = ['Timestamp', 'Full Name :']
    df.drop(columns=columns, inplace=True, axis=1)
    df.rename(columns={'Gender :': 'Gender'}, inplace=True)
    df.fillna(df.mode().iloc[0], inplace=True)
    le = LabelEncoder()

    for column in df.columns:
        # Find the most frequent value for the current column
        most_frequent_value = df[column].mode()[0]
        # Replace missing values in the current column with the most frequent value
        df[column].fillna(most_frequent_value, inplace=True)

        encoder = LabelEncoder()
    for column in df.columns:
        df[column] = encoder.fit_transform(df[column])

    # Define a mapping for the 'For how long do you use your phone for playing games?' column
    time_mapping = {
        '<2 hours': 1,
        '>2 hours': 2,
        'nan': 0,
    }

    # Apply the mapping to the column
    df['For how long do you use your phone for playing games?'] = df['For how long do you use your phone for playing games?'].replace(time_mapping)

    # Ensure Gender is encoded properly
    df['Gender'] = le.fit_transform(df['Gender'])

    time_mapping = {
        '<2 hours': 1,
        '2-4 hours': 2,
        '4-6 hours': 3,
        '6+ hours': 4
    }

    df['For how long do you use your phone for playing games?'] = df['For how long do you use your phone for playing games?'].replace(time_mapping)

    # Filter out users not addicted to phone
    df = df[df['whether you are addicted to phone?'] != 0]

    x = df.drop(['whether you are addicted to phone?'], axis=1)
    y = df['whether you are addicted to phone?']

    # Remap target variable to binary
    print("Unique values before remapping:", y.unique())
    y = y.map({1: 0, 2: 1})  # Adjust according to your actual classes if different
    print("Unique values after remapping:", y.unique())

    # Oversample the dataset
    Oversample = RandomOverSampler(random_state=72)
    x_sm, y_sm = Oversample.fit_resample(x[:400], y[:400])

    # Split the dataset
    x_train, x_test, y_train, y_test = train_test_split(x_sm, y_sm, test_size=0.3, random_state=72)

    param_grid_xgb = {
        'n_estimators': [100, 200, 300],
        'learning_rate': [0.01, 0.1, 0.2],
        'max_depth': [3, 6, 10],
        'subsample': [0.8, 1.0]
    }

    # Handle form inputs
    if request.method == 'POST':
        b = float(request.POST['f2'])
        c = float(request.POST['f3'])
        d = float(request.POST['f4'])
        e = float(request.POST['f5'])
        f = float(request.POST['f6'])
        g = float(request.POST['f7'])
        h = float(request.POST['f8'])
        i = float(request.POST['f9'])
        j = float(request.POST['f10'])
        k = float(request.POST['f11'])
        l = float(request.POST['f12'])
        m = float(request.POST['f13'])
        n = float(request.POST['f14'])
        o = float(request.POST['f15'])
        p = float(request.POST['f16'])
        q = float(request.POST['f17'])
        r = float(request.POST['f18'])
        s = float(request.POST['f19'])

       
        if request.POST.get('f3') == 'Yes' and request.POST.get('f4') == 'Yes' and request.POST.get('f17') == 'Yes' and request.POST.get('f19') == 'Yes':
            y_pred_xgb = [0] 
        else:
            data = [[b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s]]
            grid_xgb = GridSearchCV(estimator=XGBClassifier(random_state=72),
                                    param_grid=param_grid_xgb,
                                    cv=5,
                                    scoring='accuracy',
                                    n_jobs=-1,
                                    verbose=2)
            grid_xgb.fit(x_train, y_train)
            best_xgb = grid_xgb.best_estimator_
            y_pred_xgb = best_xgb.predict(data)

       
        if y_pred_xgb[0] == 0:
            msg = 'User not Addicted'
            suggestion = 'Keep up the good work! Maintain your balanced screen time for a healthy lifestyle.'
        elif y_pred_xgb[0] == 1:
            msg = 'User Addicted'
            suggestion = 'You might want to consider limiting your screen time to avoid potential negative effects on health. Try setting screen time limits and taking regular breaks.'
        
        return render(request, 'prediction.html', {'msg': msg, 'suggestion': suggestion})

    return render(request, 'prediction.html')


def graph(request):
    return render(request,'graph.html')

